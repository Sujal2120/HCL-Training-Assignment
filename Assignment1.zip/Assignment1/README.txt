Assignment 1 - Java Programs
============================
Q1_BasicMath.java         - Basic math operations using methods
Q2_ArrayMenu.java         - Menu driven 1-D array operations
Q3_MatrixOperations.java  - Matrix operations and checks
Q4_StringDemo.java        - String / StringBuffer / StringBuilder difference + String methods
Q5_BankManagement.java    - Console bank management with exception handling

How to run (example for Q1):
    javac Q1_BasicMath.java
    java Q1_BasicMath
