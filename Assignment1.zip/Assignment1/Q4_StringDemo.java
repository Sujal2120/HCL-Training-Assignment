/*
 * DIFFERENCE BETWEEN String, StringBuffer AND StringBuilder
 * ---------------------------------------------------------------------
 * Feature        | String            | StringBuffer       | StringBuilder
 * ---------------------------------------------------------------------
 * Mutability     | Immutable         | Mutable            | Mutable
 * Thread-safe    | Yes (immutable)   | Yes (synchronized) | No
 * Speed          | Slow for changes  | Slower than SB     | Fastest
 * Memory         | New object on     | Same object is     | Same object is
 *                | every change      | modified           | modified
 * Available since| Java 1.0          | Java 1.0           | Java 1.5
 * Use when       | Value won't change| Many threads edit  | Single thread edits
 *                |                   | the same text      | the same text
 * ---------------------------------------------------------------------
 */
public class Q4_StringDemo {

    public static void main(String[] args) {

        // ----- Difference demo -----
        System.out.println("===== String vs StringBuffer vs StringBuilder =====");
        String s = "Java";
        s.concat(" Programming");               // result is thrown away
        System.out.println("String after concat (unchanged): " + s);

        StringBuffer sbf = new StringBuffer("Java");
        sbf.append(" Programming");             // same object is changed
        System.out.println("StringBuffer after append: " + sbf);

        StringBuilder sbd = new StringBuilder("Java");
        sbd.append(" Programming");
        System.out.println("StringBuilder after append: " + sbd);

        // ----- String methods demo -----
        System.out.println("\n===== String Methods =====");
        String str  = "  Hello Java World  ";
        String str2 = "hello java world";

        System.out.println("Original string      : '" + str + "'");
        System.out.println("length()             : " + str.length());
        System.out.println("isEmpty()            : " + str.isEmpty());
        System.out.println("charAt(2)            : " + str.charAt(2));
        System.out.println("toString()           : " + str.toString());
        System.out.println("equals()             : " + str.equals(str2));
        System.out.println("compareTo()          : " + str.compareTo(str2));
        System.out.println("contains(\"Java\")     : " + str.contains("Java"));
        System.out.println("indexOf('o')         : " + str.indexOf('o'));
        System.out.println("lastIndexOf('o')     : " + str.lastIndexOf('o'));
        System.out.println("startsWith(\"  He\")   : " + str.startsWith("  He"));
        System.out.println("endsWith(\"d  \")      : " + str.endsWith("d  "));
        System.out.println("matches(\"[a-z ]+\")   : " + str2.matches("[a-z ]+"));
        System.out.println("substring(2, 7)      : " + str.substring(2, 7));
        System.out.println("toLowerCase()        : " + str.toLowerCase());
        System.out.println("trim()               : '" + str.trim() + "'");
        System.out.println("replace('o', '0')    : " + str.replace('o', '0'));

        String[] words = str.trim().split(" ");
        System.out.print("split(\" \")           : ");
        for (String w : words) {
            System.out.print("[" + w + "] ");
        }
        System.out.println();

        System.out.println("join(\"-\", words)     : " + String.join("-", words));
        System.out.println("valueOf(100)         : " + String.valueOf(100));
        System.out.println("valueOf(3.14)        : " + String.valueOf(3.14));
        System.out.println("valueOf(true)        : " + String.valueOf(true));
    }
}
