import java.util.Scanner;

public class Q1_BasicMath {

    static double add(double a, double b)      { return a + b; }
    static double subtract(double a, double b) { return a - b; }
    static double multiply(double a, double b) { return a * b; }

    static double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return a / b;
    }

    static double remainder(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot find remainder with zero");
        }
        return a % b;
    }

    static double square(double a)   { return a * a; }
    static double cube(double a)     { return a * a * a; }
    static double absolute(double a) { return (a < 0) ? -a : a; }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n===== BASIC MATH =====");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Remainder");
            System.out.println("6. Square");
            System.out.println("7. Cube");
            System.out.println("8. Absolute");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1: case 2: case 3: case 4: case 5:
                        System.out.print("Enter first number: ");
                        double a = sc.nextDouble();
                        System.out.print("Enter second number: ");
                        double b = sc.nextDouble();
                        double result = 0;
                        if (choice == 1) result = add(a, b);
                        else if (choice == 2) result = subtract(a, b);
                        else if (choice == 3) result = multiply(a, b);
                        else if (choice == 4) result = divide(a, b);
                        else result = remainder(a, b);
                        System.out.println("Result = " + result);
                        break;
                    case 6: case 7: case 8:
                        System.out.print("Enter a number: ");
                        double n = sc.nextDouble();
                        if (choice == 6) System.out.println("Square = " + square(n));
                        else if (choice == 7) System.out.println("Cube = " + cube(n));
                        else System.out.println("Absolute = " + absolute(n));
                        break;
                    case 0:
                        System.out.println("Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (ArithmeticException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (choice != 0);
        sc.close();
    }
}
