import java.util.Arrays;
import java.util.Scanner;

public class Q2_ArrayMenu {

    static int[] arr = new int[100];
    static int size = 0;

    static void display() {
        if (size == 0) {
            System.out.println("Array is empty.");
            return;
        }
        System.out.print("Array: ");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    static void insert(int pos, int value) {
        if (size == arr.length) {
            System.out.println("Array is full.");
            return;
        }
        if (pos < 0 || pos > size) {
            System.out.println("Invalid position. Valid range: 0 to " + size);
            return;
        }
        for (int i = size; i > pos; i--) {
            arr[i] = arr[i - 1];
        }
        arr[pos] = value;
        size++;
        System.out.println("Inserted.");
    }

    static void delete(int pos) {
        if (size == 0) {
            System.out.println("Array is empty.");
            return;
        }
        if (pos < 0 || pos >= size) {
            System.out.println("Invalid position. Valid range: 0 to " + (size - 1));
            return;
        }
        System.out.println("Deleted: " + arr[pos]);
        for (int i = pos; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        size--;
    }

    static int linearSearch(int key) {
        for (int i = 0; i < size; i++) {
            if (arr[i] == key) return i;
        }
        return -1;
    }

    static boolean isSorted() {
        for (int i = 0; i < size - 1; i++) {
            if (arr[i] > arr[i + 1]) return false;
        }
        return true;
    }

    static int binarySearch(int key) {
        int low = 0, high = size - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (arr[mid] == key) return mid;
            else if (arr[mid] < key) low = mid + 1;
            else high = mid - 1;
        }
        return -1;
    }

    static int findMax() {
        int max = arr[0];
        for (int i = 1; i < size; i++) {
            if (arr[i] > max) max = arr[i];
        }
        return max;
    }

    static void countEvenOdd() {
        int even = 0, odd = 0;
        for (int i = 0; i < size; i++) {
            if (arr[i] % 2 == 0) even++;
            else odd++;
        }
        System.out.println("Even numbers: " + even);
        System.out.println("Odd numbers : " + odd);
    }

    static void insertionSort() {
        for (int i = 1; i < size; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        System.out.println("Array sorted.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n===== ARRAY MENU =====");
            System.out.println("1. Insertion");
            System.out.println("2. Deletion");
            System.out.println("3. Linear Search");
            System.out.println("4. Binary Search");
            System.out.println("5. Find Maximum");
            System.out.println("6. Count Even / Odd");
            System.out.println("7. Insertion Sort");
            System.out.println("8. Display");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter position (0 to " + size + "): ");
                    int pos = sc.nextInt();
                    System.out.print("Enter value: ");
                    int val = sc.nextInt();
                    insert(pos, val);
                    break;
                case 2:
                    System.out.print("Enter position to delete: ");
                    delete(sc.nextInt());
                    break;
                case 3:
                    System.out.print("Enter value to search: ");
                    int idx = linearSearch(sc.nextInt());
                    System.out.println(idx == -1 ? "Not found." : "Found at index " + idx);
                    break;
                case 4:
                    if (size == 0) {
                        System.out.println("Array is empty.");
                        break;
                    }
                    if (!isSorted()) {
                        System.out.println("Array is not sorted. Use option 7 first.");
                        break;
                    }
                    System.out.print("Enter value to search: ");
                    int bi = binarySearch(sc.nextInt());
                    System.out.println(bi == -1 ? "Not found." : "Found at index " + bi);
                    break;
                case 5:
                    if (size == 0) System.out.println("Array is empty.");
                    else System.out.println("Maximum = " + findMax());
                    break;
                case 6:
                    countEvenOdd();
                    break;
                case 7:
                    insertionSort();
                    display();
                    break;
                case 8:
                    display();
                    break;
                case 0:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);
        sc.close();
    }
}
