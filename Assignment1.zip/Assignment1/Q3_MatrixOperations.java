import java.util.Scanner;

public class Q3_MatrixOperations {

    static Scanner sc = new Scanner(System.in);

    static int[][] readMatrix(String name) {
        System.out.print("Enter rows of " + name + ": ");
        int r = sc.nextInt();
        System.out.print("Enter columns of " + name + ": ");
        int c = sc.nextInt();
        int[][] m = new int[r][c];
        System.out.println("Enter elements of " + name + ":");
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                m[i][j] = sc.nextInt();
            }
        }
        return m;
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int x : row) {
                System.out.print(x + "\t");
            }
            System.out.println();
        }
    }

    static boolean sameSize(int[][] a, int[][] b) {
        return a.length == b.length && a[0].length == b[0].length;
    }

    static int[][] add(int[][] a, int[][] b) {
        int[][] res = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[0].length; j++)
                res[i][j] = a[i][j] + b[i][j];
        return res;
    }

    static int[][] subtract(int[][] a, int[][] b) {
        int[][] res = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[0].length; j++)
                res[i][j] = a[i][j] - b[i][j];
        return res;
    }

    static int[][] multiply(int[][] a, int[][] b) {
        int[][] res = new int[a.length][b[0].length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < b[0].length; j++)
                for (int k = 0; k < a[0].length; k++)
                    res[i][j] += a[i][k] * b[k][j];
        return res;
    }

    static int[][] transpose(int[][] a) {
        int[][] res = new int[a[0].length][a.length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[0].length; j++)
                res[j][i] = a[i][j];
        return res;
    }

    static boolean isSquare(int[][] a) {
        return a.length == a[0].length;
    }

    static boolean isDiagonal(int[][] a) {
        if (!isSquare(a)) return false;
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a.length; j++)
                if (i != j && a[i][j] != 0) return false;
        return true;
    }

    static boolean isIdentity(int[][] a) {
        if (!isDiagonal(a)) return false;
        for (int i = 0; i < a.length; i++)
            if (a[i][i] != 1) return false;
        return true;
    }

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n===== MATRIX MENU =====");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Transpose");
            System.out.println("5. Check Square Matrix");
            System.out.println("6. Check Diagonal Matrix");
            System.out.println("7. Check Identity Matrix");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: case 2: {
                    int[][] a = readMatrix("Matrix A");
                    int[][] b = readMatrix("Matrix B");
                    if (!sameSize(a, b)) {
                        System.out.println("Both matrices must have the same size.");
                    } else {
                        System.out.println("Result:");
                        print(choice == 1 ? add(a, b) : subtract(a, b));
                    }
                    break;
                }
                case 3: {
                    int[][] a = readMatrix("Matrix A");
                    int[][] b = readMatrix("Matrix B");
                    if (a[0].length != b.length) {
                        System.out.println("Columns of A must equal rows of B.");
                    } else {
                        System.out.println("Result:");
                        print(multiply(a, b));
                    }
                    break;
                }
                case 4: {
                    int[][] a = readMatrix("Matrix");
                    System.out.println("Transpose:");
                    print(transpose(a));
                    break;
                }
                case 5: {
                    int[][] a = readMatrix("Matrix");
                    System.out.println(isSquare(a) ? "It is a square matrix." : "It is NOT a square matrix.");
                    break;
                }
                case 6: {
                    int[][] a = readMatrix("Matrix");
                    System.out.println(isDiagonal(a) ? "It is a diagonal matrix." : "It is NOT a diagonal matrix.");
                    break;
                }
                case 7: {
                    int[][] a = readMatrix("Matrix");
                    System.out.println(isIdentity(a) ? "It is an identity matrix." : "It is NOT an identity matrix.");
                    break;
                }
                case 0:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 0);
        sc.close();
    }
}
